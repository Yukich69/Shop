﻿namespace kek
{
    partial class Shop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.DeleteProduct = new System.Windows.Forms.Button();
            this.CopyProduct = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.GetChek = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.ProductName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.AddProduct = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(505, 50);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(283, 228);
            this.listBox1.TabIndex = 0;
            // 
            // DeleteProduct
            // 
            this.DeleteProduct.Location = new System.Drawing.Point(505, 284);
            this.DeleteProduct.Name = "DeleteProduct";
            this.DeleteProduct.Size = new System.Drawing.Size(72, 24);
            this.DeleteProduct.TabIndex = 1;
            this.DeleteProduct.Text = "Delete";
            this.DeleteProduct.UseVisualStyleBackColor = true;
            this.DeleteProduct.Click += new System.EventHandler(this.DeleteProduct_Click);
            // 
            // CopyProduct
            // 
            this.CopyProduct.Location = new System.Drawing.Point(596, 284);
            this.CopyProduct.Name = "CopyProduct";
            this.CopyProduct.Size = new System.Drawing.Size(72, 24);
            this.CopyProduct.TabIndex = 2;
            this.CopyProduct.Text = "Copy";
            this.CopyProduct.UseVisualStyleBackColor = true;
            this.CopyProduct.Click += new System.EventHandler(this.CopyProduct_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(501, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 24);
            this.label1.TabIndex = 3;
            this.label1.Text = "Your Check";
            // 
            // GetChek
            // 
            this.GetChek.Location = new System.Drawing.Point(505, 369);
            this.GetChek.Name = "GetChek";
            this.GetChek.Size = new System.Drawing.Size(179, 58);
            this.GetChek.TabIndex = 4;
            this.GetChek.Text = "Get Check";
            this.GetChek.UseVisualStyleBackColor = true;
            this.GetChek.Click += new System.EventHandler(this.GetChek_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(45, 284);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "Name";
            // 
            // ProductName
            // 
            this.ProductName.Location = new System.Drawing.Point(108, 281);
            this.ProductName.Name = "ProductName";
            this.ProductName.Size = new System.Drawing.Size(123, 22);
            this.ProductName.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(45, 249);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(173, 17);
            this.label3.TabIndex = 7;
            this.label3.Text = "Search Product in Internet";
            // 
            // AddProduct
            // 
            this.AddProduct.Location = new System.Drawing.Point(116, 322);
            this.AddProduct.Name = "AddProduct";
            this.AddProduct.Size = new System.Drawing.Size(115, 37);
            this.AddProduct.TabIndex = 8;
            this.AddProduct.Text = "Add";
            this.AddProduct.UseVisualStyleBackColor = true;
            this.AddProduct.Click += new System.EventHandler(this.AddProduct_Click);
            // 
            // Shop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(815, 454);
            this.Controls.Add(this.AddProduct);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ProductName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.GetChek);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CopyProduct);
            this.Controls.Add(this.DeleteProduct);
            this.Controls.Add(this.listBox1);
            this.Name = "Shop";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Shop_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button DeleteProduct;
        private System.Windows.Forms.Button CopyProduct;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button GetChek;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox ProductName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button AddProduct;
    }
}