﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kek
{
    interface IWorkWithFile
    {
        void WriteToFile(string path, bool append);
    }
}
