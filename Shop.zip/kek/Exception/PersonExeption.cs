﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kek
{
    class PersonExeption : Exception
    {
        public PersonExeption() { }
        public PersonExeption(string message) : base(message) { }
    }
}
