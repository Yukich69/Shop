﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kek
{
    public partial class Regestration : Form
    {
        public Regestration()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = PersonName.Text;
            string surname = PersonSurname.Text;
            int age = int.Parse(PersonAge.Text);
            try
            {
                Customer customer = new Customer(name, surname, age);
                Shop shop = new Shop(customer);
                shop.Show();
                this.Hide();
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message.ToString());
            }

            
            

        }
    }
}
