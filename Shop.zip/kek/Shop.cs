﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kek
{
    public partial class Shop : Form
    {
        public Customer Current { get; set; }


        public Shop(Customer customer)
        {
            InitializeComponent();
            Current = customer;
        }



        private void Shop_Load(object sender, EventArgs e)
        {
            Current.UpDiscount += Current_UpDiscount;
        }

        private void Current_UpDiscount()
        {
            Current.discount -= 0.015;
        }

        private void AddProduct_Click(object sender, EventArgs e)
        {
            string name = ProductName.Text;
            Product temp = new Product(name);


            Current.AddProduct(temp);
            listBox1.Items.Add(temp);
        }

        private void GetChek_Click(object sender, EventArgs e)
        {
            Current.WriteToFile(@"C:\TestShop\Check.txt", false);
        }

        private void CopyProduct_Click(object sender, EventArgs e)
        {
            Current.AddProduct((Product)listBox1.SelectedItem);
            listBox1.Items.Add((Product)listBox1.SelectedItem);
        }

        private void DeleteProduct_Click(object sender, EventArgs e)
        {
            Current.RemoveProduct((Product)listBox1.SelectedItem);
            listBox1.Items.RemoveAt(listBox1.SelectedIndex);
        }
    }
}
