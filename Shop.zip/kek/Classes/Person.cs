﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kek
{
    public abstract class Person
    {
        private string name;
        private string surname;
        private int age;

        public Person(string _name, string _surname, int _age)
        {
            Name = _name;
            Surname = _surname;
            Age = _age;
        }

        public string GetFullName()
        {
            return Name +" "+ Surname;
        }

        public override string ToString()
        {
            return $"Name:{Name}\nSurname:{Surname}\nAge:{Age}";
        }

        public string Name {
            get
            {
                return name;
            }
            set 
            {
                if (value.Length > 30)
                    throw new PersonExeption("Please Enter shorter name");
                name = value;
            }
        }
        public string Surname {
            get
            {
                return surname;
            }
            set
            {
                if (value.Length > 30)
                    throw new PersonExeption("Please Enter shorter surname");
                surname = value;
            }
        }
        public int Age {
            get
            {
                return age;
            }
            set
            {
                if (value <= 0)
                    throw new PersonExeption("Not correct age");
                age = value;
            }
        }

    }
}
