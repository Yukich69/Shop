﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kek
{
    public class Product 
    {
        private string name;
        private int price;

        public Product(string _name) 
        {
            Name = _name;
            Price = rnd.Next(1,20);
        }

        public override string ToString()
        {
            return Name + ": " + price.ToString()+"$";
        }
        public int Price { 
            get 
            { 
                return price; 
            }
            set
            {
                price = value;
            }
                }
        public string Name { get; set; }

        Random rnd = new Random();
    }
}
