﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kek
{
    public class Customer : Person,IWorkWithFile,ICloneable
    {
        private List<Product> basket;
        public  double discount;
        public event Action UpDiscount;


        public Customer(string _name, string _surname, int _age) : base(_name, _surname, _age)
        {
            basket = new List<Product>();
            discount = 1;
        }

        public override string ToString()
        {
            return base.ToString() + $"\nWith discount:{discount.ToString()}%";
        }

        public void AddProduct(Product product)
        {
            basket.Add(product);
            UpDiscount?.Invoke();
        }

        public void RemoveProduct(Product product)
        {
            basket.Remove(product);
        }

        public double GetAllPrice() 
        {
            int sum = 0;
            foreach (var product in basket) 
            {
                sum += product.Price;
            }

            return sum*discount;
        
        }

        public void WriteToFile(string path, bool append)
        {
            using (StreamWriter writetext = new StreamWriter(path, append, System.Text.Encoding.Default))
            {
                writetext.WriteLine(this.ToString() + "\n\n" + "Your Basket:\n");
                foreach (var product in basket) 
                {
                    writetext.WriteLine(product.ToString() + "\n");
                }
                double price = GetAllPrice();
                writetext.WriteLine($"\n\nResult: {price}$");
            }
        }

        public object Clone()
        {
            return new Customer(this.Name, this.Surname, this.Age);
        }
    }
}
