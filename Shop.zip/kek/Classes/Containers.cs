﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kek
{


    public static class PrintCollection
    {
        public static void Print<T>(this IEnumerable<T> enumerable)
        {
            if (enumerable == null)
                return;

            foreach (var i in enumerable)
            {
                Console.WriteLine(i.ToString() + '\n');
            }

        }
    }

    class Containers
    {
        public List<Product> list;
        public Queue<Product> queue;
        public Stack<Product> stack;
        public Dictionary<string, Product> dictionary;
        public HashSet<Product> hashSat;


        public Containers()
        {
            list = new List<Product>();
            queue = new Queue<Product>();
            stack = new Stack<Product>();
            dictionary = new Dictionary<string, Product>();
            hashSat = new HashSet<Product>();
        }

      

    }
}
